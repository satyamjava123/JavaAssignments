package satya.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginToSatyaGmail
 */
@WebServlet("/LoginToSatyaGmail")
public class LoginToSatyaGmail extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String uName = request.getParameter("uname");
		String pass = request.getParameter("pwd");
		
		response.setContentType("text.html");
		PrintWriter out = response.getWriter();
		
		
		if (uName.equals("satya") && pass.equals("satya"))
		{
			//success
			out.println("<html><body><h1>Welcome  " + uName + " to Gmail"+ "</h1></body></html>");
			
			out.println("<A HREF=\"Dataone\">Country List</A><br/>");
			out.println("<A HREF=\"DataTwo.jsp\">Sent Mail</A>");
		}
		else
		{
			//error
			
			out.println("<html><body><h2 style = 'color:red'>sorry invalid Details</h2>|</body></html>");
			
		}
	}

}
