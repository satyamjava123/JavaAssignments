package satyam.medidi;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
public class Employee 
{
	//Properties Declaration
	
    private String empname;
    private int empid;

    public Employee(int empid, String empname)
    {
        this.empid = empid;
        this.empname = empname;
    }
   //Getter And Setter Methods
    
  	public String getEmpname() 
  	{
		return empname;
	}

	public void setEmpname(String empname) 
	{
		this.empname = empname;
	}

	public int getEmpid1() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public static Comparator<Employee> getEmpnameComparator() {
		return EmpNameComparator;
	}
	public static void setEmpnameComparator(Comparator<Employee> empNameComparator) {
		EmpNameComparator = empNameComparator;
	}
	public static Comparator<Employee> getEmpid() {
		return EmpID;
	}
	public static void setEmpid(Comparator<Employee> empId) {
		EmpID = empId;
	}

	public static Comparator<Employee> EmpNameComparator = new Comparator<Employee>() {

	public int compare(Employee s1, Employee s2) {
	   String Emp1 = s1.getEmpname().toUpperCase();
	   String Emp2 = s2.getEmpname().toUpperCase();

	   //ascending order
	   return Emp1.compareTo(Emp2);

	   //descending order
	   //return StudentName2.compareTo(StudentName1);
    }};

    /*Comparator for sorting the list by roll no*/
    public static Comparator<Employee> EmpID = new Comparator<Employee>() {

	public int compare(Employee s1, Employee s2) {

	   int empId1 = s1.getEmpid1();
	   int empId2 = s2.getEmpid1();

	   /*For ascending order*/
	   return empId1-empId2;

	   /*For descending order*/
	   //rollno2-rollno1;
   }};
    @Override
    public String toString() {
        return "[ EmpId is = " + empid + ", EMPloyeeName= " + empname + "]";
    }

    public static class Details  {

    	public static void main(String args[]){
    	   ArrayList<Employee> arraylist = new ArrayList<Employee>();
    	   arraylist.add(new Employee(4307, "satya"));
    	   arraylist.add(new Employee(4303, "Reddy"));
    	   arraylist.add(new Employee(11, "Akash"));
    	   arraylist.add(new Employee(3, "satya"));
    	   arraylist.add(new Employee(1, "Reddys"));
    	   arraylist.add(new Employee(23, "Naveena"));

    	   /*Sorting based on empNameName*/
    	   System.out.println("***********************************************");
    	   System.out.println( "Sorting Based On Employee Name:");
    	   Collections.sort(arraylist, Employee.EmpNameComparator);
    	  
    	   for(Employee str: arraylist){
    			System.out.println(str);
    	   }
    	   System.out.println("***********************************************");
    	   /* Sorting on empId property*/
    	   System.out.println("***********************************************");
    	   System.out.println("Sorting Based On Employee ID:");
    	   Collections.sort(arraylist, Employee.EmpID);
    	   for(Employee str: arraylist){
    			System.out.println(str);
    	   }
    	   System.out.println("***********************************************");
    	}
    }
}