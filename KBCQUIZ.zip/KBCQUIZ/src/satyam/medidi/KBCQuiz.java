package satyam.medidi;

import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

@SuppressWarnings("unused")

public class KBCQuiz {
	String questions, options, answer, enter;
	char ch;
	int i, correct = 0;
	KBCQuiz[] quiz=new KBCQuiz[3];
	int count = 0;
	
	//KbcQuizStart
	public void KbcQuizStart()
	{
		for(i=0; i<3; i++) 
		{
			quiz[i] = new KBCQuiz();
		}
		
	}
	//kbcQuizMcq
		public void kbcQuizMcq()
		{
	        try
	        {
	            quiz[0].questions="Who Developed Java?";
	            quiz[1].questions="What is the full form of JVM";
	            quiz[2].questions="What is the full form of JDK?";
	            
	           
	        }
	        catch(ArrayIndexOutOfBoundsException e)
	        {
	        	e.printStackTrace();
	            System.err.println("Error Occur!\n"+e.getMessage());
	            System.exit(0);
	        }
	    }
		
		//kbcQuizMcqOptions
		public void kbcQuizMcqOptions()
		{
	        try
	        {
	            quiz[0].options=" A.Satyam James \n B.James Gosling\n C.Gosling Satya\n D.Medidi";
	            quiz[1].options=" A.Java virtual Mechine\n B.Java void Mechine \n C.Java viral Mechine\n D.Java V Mechine";
	            quiz[2].options=" A.Java Development Kit \n B.Java Developer Kit \n C.Java Developed Kitbv\n D.Developing Kit";
	           
	        }
	        catch(ArrayIndexOutOfBoundsException e)
	        {
	            System.err.println("Error Occur!\n"+e.getMessage());
	            System.exit(0);
	        }
	    }
		//kbcQuizMcqAnswers
		
		public void kbcQuizMcqAnswers(){
	        quiz[0].answer="B";
	        quiz[1].answer="A";
	        quiz[2].answer="A";
	        		
		}
		@SuppressWarnings("resource")
		public void runKbcQuiz(){
	        try{
	            Scanner scan = new Scanner(System.in);
	            String temp="";

	            for(i=0; i<3; i++)
	            {
	            	System.out.println("............................................................");
	                System.out.println("Question "+(i+1)+": "+quiz[i].questions+"\n"+quiz[i].options );
	                System.out.printf("Enter Your Answer:"+"\n");
	                
	                temp=scan.next();
	                ch=temp.charAt(0);
	                temp=Character.toString(ch);
	                
	                
	              
	                if(temp.equalsIgnoreCase(quiz[i].answer))
	                {
	                	System.out.println("-----------------------------------------------------------");
	                	System.out.println("Question "+(i+1));
	                    System.out.println("Entered Answer is CORRECT");
	                    correct++;
//	                    System.out.println("Correct Answer is: "+quiz[i].answer );
		                System.out.println("-----------------------------------------------------------");
	                    
	                }
	                else
	                {
	                	System.out.println("-----------------------------------------------------------");
	                	System.out.println("Question "+(i+1));
	                    System.out.println("Entered Answer is INCORRECT");
	                    System.out.println("Correct Answer is: "+quiz[i].answer );
		                System.out.println("-----------------------------------------------------------");
	                }
	                
	                
	            }
	        }
	        
	        catch(ArrayIndexOutOfBoundsException e)
	        {
	            System.err.println("Error Occur3c!\n"+e.getMessage());
	            System.exit(0);
	        }
	        catch(InputMismatchException e)
	        {
	            System.err.println("Error Occur1!\n"+e.getMessage());
	            System.exit(0);
	        }
	    }
		//Result Validation
		public void KbcQuizAssessments()
		{
			
			System.out.println("******************************************************************");
	        System.out.println("------------------ Your Final Assessment:- -----------------------");
	        System.out.println("You answered 3 questions out of \n"+correct+" Correct and \n"+(3-correct)+" Incorrect!");
	        System.out.println("*******************************************************************");
	       
	        
		}
		
		


//Main
	public static void main(String[] args) 
	{
		
		System.out.println("Name:Medidi Satyam");
		KBCQuiz Object = new KBCQuiz();
		Object.KbcQuizStart();
		Object.kbcQuizMcq();
		Object.kbcQuizMcqOptions();
		Object.kbcQuizMcqAnswers();
		Object.runKbcQuiz();
		Object.KbcQuizAssessments();    
	}
}